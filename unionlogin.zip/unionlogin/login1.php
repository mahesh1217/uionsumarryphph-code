<html>
    <head>
        <title>Login Form</title>
    </head>
    <body>
        <form action="login.php" method="POST">
            userid:<input type="text" name="userid" ><br><br/>
            Password:<input type="password" name="password"><br><br/>
            <input type="submit" value="submit">
        </form>
    </body>
</html>