 <?php
$conn = new mysqli("localhost", "root", "","mydb");
  
if ($conn->connect_error) {
  die("ERROR: Unable to connect: " .$conn->connect_error);
} 

?>