<html>
    <head>
        <title>Account Summary</title>
        
<meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="unionsum.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <img src="unionlogo.png">
        <div class="name">
          <strong>Welcome:Manish Bharath</strong>
        </div>
        <div class="gear">
          <i style="font-size:24px" class="fa">&#xf013;</i>
          <select><option></option></select>
        </div>
         <button class="btn">Logout</button>
    <nav>
        <ul>
            <li><a>Dashboard</a></li>
            <li><a>Accounts</a></li>
            <li><a>ASBA</a></li>
            <li><a>Demat</a></li>
            <li><a>Transactions</a></li>
            <li><a>General Services</a></li>
            <li><a>Bill Presentment</a></li>
            <li><a>FD Opening</a></li>
            <li><a></a>Feedback</li>
            <li><a></a>Personalize Limits</li>
        </ul>
    </nav>
    <div class="line">
        <ul>
            <li><a>Accounts:</a></li>
            <li>Balance & Transaction nfo &nbsp;<i class="fa fa-angle-right" style="font-size:20px;color:red"></i>&nbsp;</li>
            <li style="font-weight: bold;">Account Summary<i class="fa fa-angle-right" style="font-size:20px;color:red"></i></li>
            <li>Account Summary</li>
        </ul>
    </div>
    <div class="print">
        <i class="fa fa-print" onclick="myFunction()" style="font-size:24px"></i>
    </div>
    <br>
    <br>
    <br>
    <br>
    
         <div class="acc">Accounts</div>
    <table>
            <tr>
              <td colspan= "4" style="background: white;"><button style="height: 30px;width: 80px;">Search<i class="fa fa-search"></i></button></td>
            </tr>
            <tr>
              <td colspan="4">Account Summary List</td>
            </tr>
            <tr style="background: lightgray;">
              <td style="border-right:  rgb(163,158,158);">Account Number
                <br><br>
                Account Holder
              </td>
              <td style="border-right:   rgb(163,158,158);">Account Type
                <br><br>
                &nbsp;&nbsp;
              </td>
              <td style="border-right: rgb(163,158,158);">Status<br><br>&nbsp;&nbsp;</td>
              <td style="text-align: right;">Balance<br><br>&nbsp;</td>
            </tr>
           
            <tr>
              <td style="border-right-color: white;">
                <br><br>
                
              </td>
              <td style="border-right-color: white;">Savings
                <br><br>&nbsp;
              </td>
              <td style="border-right-color: white;">Active
                <br><br>
                &nbsp;
              </td>
              <td>
                balance:
                <br><br>
                Avb INR:
              </td>
            </tr>
            <tr>
              <td colspan="4" style="height:40px;"><i style="font-size:24px" class="fa fa-rotate-45">&#xf08d;</i>&nbsp;&nbsp;
               
            Download Details As <select style="width: 60px;"><option>PDF</option></select>&nbsp;&nbsp;
            <button style="font-size:24px;background: none;border:none;"><i class="fa fa-arrow-right"></i></button>

              </td>

            </tr>
          </table> 

      <div class="box">
        <h5>Favourites:</h5>
        <p>Select your favourite activity</p>

        <select class="sel">
          <option>select:</option>
          <option>0</option>
          <option>1</option>
          <option>2</option>  
        </select>
        <h5 class="h5"><a href="#"><i class="fa fa-star-o" style="font-size:20px;color :lightgray"></i>Add to Favourites</a></h5>

      </div>
     
      <div class="box2">
        <p>Navigate to....</p>
      </div>

      <script>
          function myFunction() {
            window.print();
          }
          </script>

    </body>
</html>
<?php
include("database.php");
extract($_POST);
if(isset($submit))
{
	$rs=mysqli_query($conn,"select * from `union` where userid='$userid' and password='$password'");
	if( $rs->num_rows > 0 )
{
		$found="N";
	}
	else
	{
		$_SESSION["login"]=$userid;
	}
}
/*
else{
	echo "Invalid Username/Password";
	include('unsucess.php');
}*/
if (isset($_SESSION["login"]))
{
header("location:login.html");
}else{
  
$sql =" SELECT `accno`,`AccHolderName`, `balance` FROM `union` where (userid='$userid' && password='$password')";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
        echo  "<p align='left'style='margin-top:-100px;margin-left:50px'>".$row["accno"]."<br>"; 
        echo  "<p align='left'style='margin-top:-40px;margin-left:930px'>".$row["balance"]."<br>"; 
        echo  "<p align='left'style='margin-top:0px;margin-left:50px'>".$row["AccHolderName"]."<br>"; 
    
    }
} else {
    echo "0 results";
}
}
  $conn->close();
  exit;

?>                                                          